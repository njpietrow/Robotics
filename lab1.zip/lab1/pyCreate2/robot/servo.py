"""
Module to control a Parallax Servo.
This is a template only and needs to be finished in Lab2
"""


class Servo:
    def __init__(self, number):
        """Constructor.

        Args:
            number (integer): PWM number where the servo is connected to.
        """
        pass
